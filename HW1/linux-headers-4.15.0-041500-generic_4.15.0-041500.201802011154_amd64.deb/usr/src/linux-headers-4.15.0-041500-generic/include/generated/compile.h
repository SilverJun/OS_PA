/* This file is auto generated, version 201802011154 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201802011154 SMP Thu Feb 1 11:55:45 UTC 2018"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc version 7.2.0 (Ubuntu 7.2.0-8ubuntu3.1)"
